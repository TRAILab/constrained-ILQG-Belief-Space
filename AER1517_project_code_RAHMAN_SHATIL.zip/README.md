bsp-ilqg-vision
=============

Belief Space Motion Planning Using iLQG. Builds on top of iLQG Matlab implementation by Yuval Tassa and
the paper "Motion Planning under Uncertainty using Iterative Local Optimization in Belief Space", Van den berg et al., 
International Journal of Robotics Research, 2012

How To
=============

Simply run the main.m file to see the demo.
For the easy course, just click run. For the hard course, uncomment line 12.


