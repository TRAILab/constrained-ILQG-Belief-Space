function c = tt(a,b)
c = bsxfun(@times,a,b);
end