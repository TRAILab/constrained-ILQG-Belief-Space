function c = pp(a,b)
c = bsxfun(@plus,a,b);
end